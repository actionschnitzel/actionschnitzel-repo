
~/pi-apps/uninstall
